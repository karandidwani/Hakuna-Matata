# Enterprise Software Technology

Goal and purpose of the system:
This website is a site where user can buy product sold by other user. Also users can auction their products where other users can bid on it. After bidding slot of 4 days, the auction gets over and highest bidder can get a message to pay for the item in Auction tab.
